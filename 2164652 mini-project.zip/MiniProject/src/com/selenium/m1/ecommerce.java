package com.selenium.m1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ecommerce {
	@Test
	public void opening() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Vaishnavi\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get(" http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		WebElement womenbtn=driver.findElement(By.linkText("Women"));
		womenbtn.click();
		String pagetitle=driver.getTitle();
		Assert.assertEquals(pagetitle,"Women - My Store");
		Thread.sleep(1000);
		WebElement topsbtn=driver.findElement(By.partialLinkText("Tops"));
		topsbtn.click();
		String pg2=driver.getTitle();
		Assert.assertEquals(pg2, "Tops - My Store");
		Thread.sleep(1000);
		WebElement tshirtbtn=driver.findElement(By.xpath("//a[@title='T-shirts']//img[@class='replace-2x']"));
		tshirtbtn.click();
		String pg3=driver.getTitle();
		Assert.assertEquals(pg3,"T-shirts - My Store");
		Thread.sleep(1000);
		Actions actions = new Actions(driver);
		WebElement block=driver.findElement(By.xpath("//*[@id='center_column']/ul/li[1]/div"));
		actions.moveToElement(block).perform();
		Thread.sleep(2000);
		WebElement more=driver.findElement(By.xpath("//*[@id='center_column']/ul/li[1]/div/div[2]/div[2]/a[2]/span"));
		more.click();
		Thread.sleep(1000);
		WebElement increase=driver.findElement(By.xpath("//i[@class='icon-plus']"));
		increase.click();
		Thread.sleep(1000);
		driver.close();
		/*WebElement morebtn=driver.findElement(By.xpath("//span[text()='More']"));
		morebtn.click();
		String pg4=driver.getTitle();
		Assert.assertEquals(pg4, "Faded Short Sleeve T-shirts - My Store");
		Thread.sleep(1000);
		driver.close();*/
	}

}

